package org.zkoss.zkgrails;

public interface GrailsFacadeClass {

}