@artifact.package@class @artifact.name@ extends GrailsComposer {

    def btnOK
    
    def onClick_btnOK {
        btnOK.label = "hello"
    }
}
