@artifact.package@import org.zkoss.zkgrails.*

class @artifact.name@ extends GrailsComposer {

    def afterCompose = { window ->
        // initialize components here
    }
}
