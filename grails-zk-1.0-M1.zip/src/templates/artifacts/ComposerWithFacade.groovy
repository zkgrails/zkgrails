@artifact.package@import org.zkoss.zkgrails.*

class @artifact.name@ extends GrailsComposer {

    def @artifact.name.prop@Facade

    def afterCompose = { window ->
        // initialize components here
    }
}
